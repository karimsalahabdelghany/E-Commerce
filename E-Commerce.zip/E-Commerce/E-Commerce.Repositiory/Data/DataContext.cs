﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using E_Commerce.Core.Entites;
using Microsoft.EntityFrameworkCore;

namespace E_Commerce.Repositiory.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions <DataContext>options) : base(options)
        {
        }
        public DbSet<Product> Products { get; set; }
        public DbSet<Product> ProductBrands { get; set; }
        public DbSet<Product> Producttypes { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}
