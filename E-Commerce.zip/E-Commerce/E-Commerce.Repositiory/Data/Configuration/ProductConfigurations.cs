﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using E_Commerce.Core.Entites;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace E_Commerce.Repositiory.Data.Configuration
{
    internal class ProductConfigurations : IEntityTypeConfiguration<Product>
    {
        public void Configure(EntityTypeBuilder<Product> builder)
        {
            builder.HasOne(product => product.productBrand).WithMany()
                .HasForeignKey(product => product.BrandId);

            builder.HasOne(product => product.ProductType).WithMany()
                .HasForeignKey(product => product.TypeId);

            builder.Property(p => p.Price).HasColumnType("decimal(18,5)");
           

        }
    }
}
