﻿
using AutoMapper;
using E_Commerce.Core.DataTransferObjects;
using E_Commerce.Core.Entites;
using E_Commerce.Core.Interfaces.Repoistries;
using E_Commerce.Core.Interfaces.Services;

namespace E_Commerce.Services
{
    public class ProductService : IProductService
    {
        private readonly IUintofWork _uintofWork;
        private readonly IMapper _mapper;

        public ProductService(IUintofWork uintofWork,IMapper mapper)
        {
            _uintofWork = uintofWork;
            _mapper = mapper;
        }
        public async Task<IEnumerable<BrandTypeDto>> GetAllBrandsAsync()
        {
            var Brands =await _uintofWork.Repository<ProductBrand,int>().GetAllAsync();
            return _mapper.Map<IEnumerable<BrandTypeDto>>(Brands);
        }

        public async Task<IEnumerable<ProductToReturnDto>> GetAllProductsAsync()
        {
            var Products = await _uintofWork.Repository<Product, int>().GetAllAsync();
            return _mapper.Map<IEnumerable<ProductToReturnDto>>(Products);
        }

        public async Task<IEnumerable<BrandTypeDto>> GetAllTypesAsync()
        {
            var types = await _uintofWork.Repository<ProductType, int>().GetAllAsync();
            return _mapper.Map<IEnumerable<BrandTypeDto>>(types);
        }

        public async Task<ProductToReturnDto> GetProductAsync(int id)
        {
            var product = await _uintofWork.Repository<Product, int>().GetAsync(id);
            return _mapper.Map<ProductToReturnDto>(product);
        }
    }
}
