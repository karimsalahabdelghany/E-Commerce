﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E_Commerce.Core.DataTransferObjects
{
    public class BrandTypeDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
