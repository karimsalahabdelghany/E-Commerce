﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using E_Commerce.Core.DataTransferObjects;
using E_Commerce.Core.Entites;

namespace E_Commerce.Core.Interfaces.Services
{
    public interface IProductService
    {
        Task<IEnumerable<ProductToReturnDto>>GetAllProductsAsync();
        Task <ProductToReturnDto> GetProductAsync(int id);
        Task<IEnumerable<BrandTypeDto>>GetAllBrandsAsync();
        Task<IEnumerable<BrandTypeDto>>GetAllTypesAsync();
    }
}
