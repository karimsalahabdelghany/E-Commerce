﻿using System.Collections.Generic;
using E_Commerce.Core.DataTransferObjects;
using E_Commerce.Core.Interfaces.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace E_Commerce.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService _productService;

        public ProductsController(IProductService productService)
        {
            _productService = productService;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProductToReturnDto>>> GetProducts()
            => Ok(await _productService.GetAllProductsAsync());
        [HttpGet("{id}")]
        public async Task<ActionResult<ProductToReturnDto>> GetProduct(int id)
            => Ok(await _productService.GetProductAsync(id));
        [HttpGet("brands")]
        public async Task<ActionResult<IEnumerable<BrandTypeDto>>> GetBrands()
            => Ok(await _productService.GetAllBrandsAsync());
        [HttpGet("Types")]
        public async Task<ActionResult<IEnumerable<BrandTypeDto>>> GetTypes()
            => Ok(await _productService.GetAllTypesAsync());
    }
}
