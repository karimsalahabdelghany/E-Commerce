﻿using AutoMapper;
using E_Commerce.Core.DataTransferObjects;
using E_Commerce.Core.Entites;
namespace E_Commerce.Api.Helper

{
    public class PictureUrlResolver : IValueResolver<Product, ProductToReturnDto, string>
    {
        public string Resolve(Product source, ProductToReturnDto destination, string destMember, ResolutionContext context)
        {
            return $"{source.PictureUrl}";
           
        }
    }
}
