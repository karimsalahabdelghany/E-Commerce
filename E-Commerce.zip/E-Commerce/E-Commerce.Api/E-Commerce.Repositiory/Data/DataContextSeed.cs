﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using E_Commerce.Core.Entites;
using Microsoft.EntityFrameworkCore;

namespace E_Commerce.Repositiory.Data
{
    public class DataContextSeed
    {
        public static async Task SeedDataAsync(DataContext context)
        {
           if(!context.Set<ProductBrand>().Any()) 
            {
                //1-Read data from Files
                var brandsdata = await File
                    .ReadAllTextAsync(@"..\E-Commerce.Repositiory\Data\DataSeeding\brands.json");
                //2.convert data to c# objects
                var brands = JsonSerializer.Deserialize<List<ProductBrand>>(brandsdata);
                //insert data into database
                if (brands is not null && brands.Any())
                {
                    await context.Set<ProductBrand>().AddRangeAsync(brands);
                    await context.SaveChangesAsync();
                }

            }
            if (!context.Set<ProductType>().Any())
            {
                //1-Read data from Files
                var typesdata = await File
                    .ReadAllTextAsync(@"..\E-Commerce.Repositiory\Data\DataSeeding\types.json");
                //2.convert data to c# objects
                var types = JsonSerializer.Deserialize<List<ProductType>>(typesdata);
                //insert data into database
                if (types is not null && types.Any())
                {
                    await context.Set<ProductType>().AddRangeAsync(types);
                    await context.SaveChangesAsync();
                }

            }
            if (!context.Set<Product>().Any())
            {
                //1-Read data from Files
                var productsdata = await File
                    .ReadAllTextAsync(@"..\E-Commerce.Repositiory\Data\DataSeeding\products.json");
                //2.convert data to c# objects
                var products = JsonSerializer.Deserialize<List<Product>>(productsdata);
                //insert data into database
                if (products is not null && products.Any())
                {
                    await context.Set<Product>().AddRangeAsync(products);
                    await context.SaveChangesAsync();
                }

            }
        }

        public static async Task SeedDataAsync(DbContext context)
        {
            throw new NotImplementedException();
        }
    }
}
