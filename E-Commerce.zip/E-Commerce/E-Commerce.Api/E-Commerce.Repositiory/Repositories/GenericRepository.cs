﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using E_Commerce.Core.Entites;
using E_Commerce.Core.Interfaces.Repoistries;
using E_Commerce.Repositiory.Data;
using Microsoft.EntityFrameworkCore;

namespace E_Commerce.Repositiory.Repositories
{
    public class GenericRepository<TEntity, Tkey> : IGenericRepository<TEntity, Tkey> where TEntity : BaseEntity<Tkey>
    {
        private readonly DataContext _context;

        public GenericRepository(DataContext context) 
        {
            _context = context;
        }

        public async Task AddAsync(TEntity entity)
        =>await _context.Set<TEntity>().AddAsync(entity);

        public void Delete(TEntity entity)
        {
            _context.Set<TEntity>().Remove(entity);
        }

        public async Task<IEnumerable<TEntity>> GetAllAsync()
        =>await _context.Set<TEntity>().ToListAsync();

        public async Task<TEntity> GetAsync(Tkey id)
        => (await _context.Set<TEntity>().FindAsync(id))!;


        public void Update(TEntity entity)
        => _context.Set<TEntity>().Update(entity);
    }
}
