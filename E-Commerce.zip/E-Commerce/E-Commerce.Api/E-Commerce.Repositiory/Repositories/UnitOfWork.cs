﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using E_Commerce.Core.Entites;
using E_Commerce.Core.Interfaces.Repoistries;
using E_Commerce.Repositiory.Data;

namespace E_Commerce.Repositiory.Repositories
{
    public class UnitOfWork : IUintofWork
    {
        private readonly DataContext _context;
        private readonly Hashtable _repositories;

        public UnitOfWork(DataContext context) 
        {
            _context = context;
            _repositories = new Hashtable();
        }

        public IGenericRepository<TEntity, Tkey> Repository<TEntity, Tkey>() where TEntity : BaseEntity<Tkey>
        {
            var typeName = typeof(TEntity).Name;
            if (!_repositories.ContainsKey(typeName))
            {
                var repo = new GenericRepository<TEntity, Tkey>(_context);
                _repositories.Add(typeName, repo);
                return repo;
            }
            return (_repositories[typeName] as GenericRepository<TEntity, Tkey>)!;
            
        }
        public async Task<int> CompleteAsync()
        => await _context.SaveChangesAsync();



        public async ValueTask DisposeAsync()
       => await _context.DisposeAsync();
    }
}
