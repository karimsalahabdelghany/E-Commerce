using System.Reflection;
using E_Commerce.Api.Helper;
using E_Commerce.Core.Entites;
using E_Commerce.Core.Interfaces.Repoistries;
using E_Commerce.Core.Interfaces.Services;
using E_Commerce.Repositiory.Data;
using E_Commerce.Repositiory.Repositories;
using E_Commerce.Services;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
namespace E_Commerce.Api
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            #region Services
            // Add services to the container.
            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();
            
            builder.Services.AddDbContext<DataContext>(o=>
             o.UseSqlServer(builder.Configuration.GetConnectionString("SQLConnection"))
            );
            builder.Services.AddScoped<IProductService, ProductService>();
            builder.Services.AddScoped<IUintofWork, UnitOfWork>();
            //builder.Services.AddAutoMapper(x => x.AddProfile(new MappingProfile()));
            builder.Services.AddAutoMapper(Assembly.GetExecutingAssembly());
            #endregion
            var app = builder.Build();
            await InitilzieDbAsync(app);
            #region Piplines
            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
            #endregion
           
        }
        private static async Task InitilzieDbAsync(WebApplication app)
        {
            using(var scope = app.Services.CreateScope())
            {
                var service = scope.ServiceProvider;
                var loggerFactory = service.GetRequiredService<ILoggerFactory>();
                try
                {
                    //create db is doesnt exists
                    var context = service.GetRequiredService<DbContext>();
                    if((await context.Database.GetPendingMigrationsAsync()).Any())
                       
                        await context.Database.MigrateAsync();
                      //apply seeding
                     await DataContextSeed.SeedDataAsync(context); 

                    
                }
                catch (Exception ex)
                {
                    var logger = loggerFactory.CreateLogger<Program>();
                    logger.LogError(ex.Message);
                }
            }
            
           
            
        }
    }
}
